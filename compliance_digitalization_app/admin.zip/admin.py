from django.contrib import admin
from compliance_digitalization_app.models import *
from django_admin_listfilter_dropdown.filters import (
    DropdownFilter, ChoiceDropdownFilter, RelatedDropdownFilter
)

# Register your models here.

class InputFramingModuleInline(admin.TabularInline):
    model = InputFramingModuleInlineInformation


class SubjectListFilter(admin.SimpleListFilter):
    title = 'clause_no'
    parameter_name = 'clause_no'


    def lookups(self, request, model_admin):
        return (
            ('', 'clause_no'),
        )
    def queryset(self, request, queryset):

        if request.GET.get('clause_no'):

            list = InputFramingModuleInlineInformation.objects.filter(compliance_owner_function__id=request.GET.get('clause_no')).values_list('InputFramingModule_id', flat=True)

            return queryset.filter(id__in=list)


class InputFramingModuleAdmin(admin.ModelAdmin):
   inlines = [InputFramingModuleInline,]
   list_display = ('compliance_id', 'title', 'benchmark', 'compliance_performance')
   list_display_links = ('compliance_id', 'title', )
   list_per_page = 10
   list_filter = (
       # for ordinary fields
       ('title', DropdownFilter),
       # ('compliance_owner_function', DropdownFilter),
       # ('compliance_owner_function', DropdownFilter),
       SubjectListFilter
   )
   search_fields = ('unique_id', 'title', 'benchmark', 'compliance_performance')

   def compliance_id(self, obj):
       return obj.unique_id

   compliance_id.short_description = 'Compliance ID'

   def changelist_view(self, request, extra_context=None):
       response = super(InputFramingModuleAdmin, self).changelist_view(request,
                                                           extra_context)
       if object is not None:
           extra_context = {
               'compliance_owners': ComplianceOwner.objects.all()
  }
           response.context_data.update(extra_context)
       return response




admin.site.register(ComplianceCategory)
admin.site.register(Type)
admin.site.register(InputFramingModule, InputFramingModuleAdmin)
admin.site.register(User)
admin.site.register(ComplianceOwner)
admin.site.register(InputFramingModuleInlineInformation)
admin.site.register(InputModule)
admin.site.site_header = "Compliance Automation Admin"
admin.site.site_title = "Compliance Automation Portal"
admin.site.index_title = "Welcome to Compliance Automation Portal"
